<?php
/**
 * Font Pack
 *
 * @since 1.5.0
 */
class 
	Listify_Customize_Control_ControlGroup_FontPack
extends 
	Listify_Customize_Control_ControlGroup {

	public function __construct( $manager, $id, $args = array() ) {
		parent::__construct( $manager, $id, $args );
	}

}
