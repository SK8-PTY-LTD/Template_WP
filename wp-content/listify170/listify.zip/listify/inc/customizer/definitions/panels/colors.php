<?php
/**
 * Colors
 *
 * @since 1.5.0
 */

$wp_customize->add_panel( 'colors', array(
	'title' => _x( 'Colors', 'customizer panel title', 'listify' ),
	'priority' => 30
) );
