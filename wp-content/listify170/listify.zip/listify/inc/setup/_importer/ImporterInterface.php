<?php
/**
 * Importer
 *
 * @since 1.0.0
 */
interface Astoundify_ImporterInterface {
	public function stage();
	public function parse_files();
}
