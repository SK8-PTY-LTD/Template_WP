<?php
function cml_admin_flags_to_list() {
  //Aggiungo i campi extra alle "custom taxonomies"
  //$taxonomies=get_taxonomies();
  //foreach($taxonomies as $taxonomy) {
  //  add_action("${taxonomy}_edit_form_fields", 'cml_admin_add_flag_column' ); 
  //  add_action("${taxonomy}_add_form_fields", 'cml_admin_add_flag_column' );
  //}
}
?>