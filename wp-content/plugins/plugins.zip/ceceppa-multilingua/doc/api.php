<div class="wrap">
  <h2>Ceceppa Multilingua: Api</h2>
    <iframe class="cml-iframe" src="<?php echo CML_PLUGIN_DOC_URL ?>/api/index.html" style="width: 100%; height: 600px"></iframe>
</div>