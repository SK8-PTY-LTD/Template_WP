
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","cml_dropdown_langs()"],["f","cml_get_browser_lang()"],["f","cml_get_menu()"],["f","cml_get_notice()"],["f","cml_get_the_link()"],["f","cml_is_homepage()"],["f","cml_show_flags()"],["c","CMLLanguage"],["c","CMLPost"],["c","CMLTranslations"],["c","CMLUtils"]];
